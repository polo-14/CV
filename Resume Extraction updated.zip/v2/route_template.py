from flask import Flask, request, jsonify, Blueprint, current_app

import json

from functions_common import sentiment_analysis
from functions_common import keyword_extractor



Instagram = Blueprint('Instagram', __name__)

        
#API to check the status of Instagram
@AppleStore.route('/status', methods=['GET'])
def status_instagram():
        current_app.logger.info("Instagram is running")
        return jsonify(message="Instagram is running"),200
