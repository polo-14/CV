from langchain.prompts import PromptTemplate

template = """
You are a resume parser. Extract all relevant information from the resume text below and return ONLY the JSON object in the exact structure shown. Do not include explanations or any other text.

If any field is not available, set its value to null. Arrays can be empty. Ensure the JSON is syntactically correct.

Extraction & Formatting Rules:
If a field is not present, set it to null.
Skills must be a single string with comma-separated values, like: "Python, Java, SQL" (not a list).
Experience** should be a whole number of years (e.g., 4, 6) — round up or down as needed.
Do not include any explanatory text — only return the raw JSON object.

Resume Text:
{resume_text}

Return only this JSON structure:

{{
  "candidateId": null,
  "firstName": null,
  "lastName": null,
  "email": null,
  "phone": null,
  "mobile": null,
  "idNumber": null,
  "nationality": null,
  "taAdmin": null,
  "location": null,
  "visaMaturityDate": null,
  "idType": null,
  "experience": null,
  "noticePeriod": null,
  "currentJobTitle": null,
  "currentCompany": null,
  "highestQualification": null,
  "skills": null,
  "streetAddress": null,
  "city": null,
  "state": null,
  "country": null,
  "postalCode": null,
  "educationDetails": [],
  "workExperience": [],
  "candidateStatus": null,
  "availabilityStatus": null,
  "candidateOwner": null,
  "taConsultant": null,
  "accountOwner": null,
  "uploadSessionId": null,
  "resumes": [],
  "createdAt": null,
  "updatedAt": null,
  "createdBy": null,
  "updatedBy": null
}}
"""


# add prompt template 
prompt = PromptTemplate.from_template(template)