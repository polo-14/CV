from flask import Flask, request, jsonify, Blueprint, current_app

import json

from apify_client import ApifyClient
from functions_common import datetime_analysis
from functions_common import text_analysis
from function_save_image import save_image_from_url

TikTok = Blueprint('TikTok', __name__)


def tiktok_scrapper_post_by_hashtag(api_key,mention,until,limit=10):
        try:
                client = ApifyClient(api_key)
                # Prepare the Actor input
                run_input = {
                                "hashtags": mention.split(","),
                                "newestPostDate": until,
                                "resultsPerPage": limit,
                                "proxyCountryCode": "None",
                                "excludePinnedPosts": False,
                                "shouldDownloadAvatars": False,
                                "shouldDownloadCovers": False,
                                "shouldDownloadMusicCovers": False,
                                "shouldDownloadSlideshowImages": False,
                                "shouldDownloadSubtitles": False,
                                "shouldDownloadVideos": False
                                }
                #Actor : clockworks/tiktok-scraper
                run = client.actor("GdWCkxBtKWOsKjdch").call(run_input=run_input)
                return run
        except Exception as e:
                current_app.logger.error("Error in function tiktok_scrapper_post_by_hashtag : "+str(e))
                print("Error in function tiktok_scrapper_post_by_hashtag : "+str(e))
                return []


#API to check the status of Instagram
@TikTok.route('/status', methods=['GET'])
def status_tiktok():
        current_app.logger.info("TikTok is running")
        return jsonify(message="TikTok is running"),200





@TikTok.route('/get-post-by-hashtags', methods=['POST'])
def tiktok_get_post_by_hashtag():
        try:
                api_key = request.form['api_key']
                mention =  request.form['mention']
                limit = int(request.form['limit']) or 20
                folder_id =  "tiktok_"+(request.form['folder_id'] or "tiktok_temp")
                time_filter = request.form.get('time_filter', '1d')
                current_app.logger.info("Fetching TikTok Hashtag details for : "+str(mention))

                #Calculating Time filter
                until = datetime_analysis.calculate_end_date("1d").strftime("%Y-%m-%d")
                
                #config scrapper run
                run = tiktok_scrapper_post_by_hashtag(api_key,mention,until,limit)

                #fetching post details
                client = ApifyClient(api_key)
                posts = []
                for item in client.dataset(run["defaultDatasetId"]).iterate_items():
                        try:
                                post = {}
                                post["mention"] = item["input"]
                                post["id"] = item["id"]
                                post["timestamp"] = item["createTime"]
                                post["date"] = item["createTimeISO"]
                                post["isAd"] = item.get("isAd", False)
                                post["isMuted"] = item.get("isMuted", False)
                                post["img"] = save_image_from_url(item["videoMeta"]["originalCoverUrl"], folder_id)

                                #author details
                                post["author"] = {}
                                post["author"]["id"] = item["authorMeta"]["id"]
                                post["author"]["name"] = item["authorMeta"]["name"]
                                post["author"]["nickName"] = item["authorMeta"]["nickName"]
                                post["author"]["url"] = item["authorMeta"]["profileUrl"]
                                post["author"]["verified"] = item["authorMeta"]["verified"]
                                post["author"]["privateAccount"] = item["authorMeta"]["privateAccount"]
                                post["author"]["ttSeller"] = item["authorMeta"].get("ttSeller","")
                                post["author"]["following"] = item["authorMeta"]["following"]
                                post["author"]["friends"] = item["authorMeta"]["friends"]
                                post["author"]["fans"] = item["authorMeta"]["fans"]
                                post["author"]["heart"] = item["authorMeta"]["heart"]
                                post["author"]["video"] = item["authorMeta"]["video"]
                                post["author"]["digg"] = item["authorMeta"]["digg"]
                                post["author"]["img"] = save_image_from_url(item["authorMeta"]["originalAvatarUrl"], folder_id)

                                #location details
                                post["locationMeta"] = item.get("locationMeta", "")

                                #media meta
                                post["mediaMeta"] = {}
                                post["mediaMeta"]["duration"] = item["videoMeta"]["duration"]
                                post["mediaMeta"]["definition"] = item["videoMeta"]["definition"]
                                post["mediaMeta"]["format"] = item["videoMeta"]["format"]
                                post["mediaMeta"]["musicName"] = item["musicMeta"]["musicName"]
                                post["mediaMeta"]["musicAuthor"] = item["musicMeta"]["musicAuthor"]
                                post["mediaMeta"]["musicOriginal"] = item["musicMeta"]["musicOriginal"]
                                post["mediaMeta"]["musicId"] = item["musicMeta"]["musicId"]

                                #counts & insights
                                post["diggCount"] = item.get("diggCount", "")
                                post["shareCount"] = item.get("shareCount", "")
                                post["playCount"] = item.get("playCount", "")
                                post["collectCount"] = item.get("collectCount", "")
                                post["commentCount"] = item.get("commentCount", "")
                                post["tagged"] = item.get("mentions", "")
                                post["effectStickers"] = item.get("effectStickers", "")
                                post["isSlideshow"] = item.get("isSlideshow", "")
                                post["isPinned"] = item.get("isPinned", "")
                                post["isSponsored"] = item.get("isSponsored", "")
                                post["searchHashtag"] = item.get("searchHashtag", "")

                                #post text
                                post["lang"] = item.get("textLanguage", "")
                                post["text"] = item["text"]
                                analysis = json.loads(text_analysis.get_insight(item["text"]))
                                post["sentiment"] = analysis["sentiment"]
                                post["tags"] = analysis["tags"]
                                post["tansalated"] = analysis["tansalated"]
                                posts.append(post)
                        except Exception as e:
                                #loop exception
                                current_app.logger.error("Error in function tiktok_get_post_by_hashtag : "+str(e))
                                print("Error in function tiktok_get_post_by_hashtag : "+str(e))
                                continue
                return jsonify(posts)
        except Exception as e:
                current_app.logger.error("Error in function tiktok_get_post_by_hashtag : "+str(e))
                print("Error in function tiktok_get_post_by_hashtag : "+str(e))
                return []
                                
