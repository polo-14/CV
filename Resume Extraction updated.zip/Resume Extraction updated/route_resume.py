from flask import Blueprint, request, jsonify, current_app
from function_common.extractPDF import extract_pdf_text
from function_common.extractDOCS import extract_docx_text
from helper.prompt import prompt
import json
from langchain_groq import ChatGroq

# Blueprint initialization
ExtractResume = Blueprint('extract_resume', __name__)
ALLOWED_EXTENSIONS = {'pdf', 'docx'}

# ✅ Check file type
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# ✅ Core function to process resume with LLM
def process_resume_llm(api_key, model_name, file):
    current_app.logger.info("Initializing LLM with model: %s", model_name)

    # Initialize the LLM
    llm = ChatGroq(
        temperature=0.2,
        model_name=model_name,
        api_key=api_key
    )

    filename = file.filename
    ext = filename.rsplit('.', 1)[1].lower()

    if not allowed_file(filename):
        current_app.logger.warning("Invalid file type attempted: %s", filename)
        raise ValueError("Invalid file type. Only PDF and DOCX are supported.")

    # Extract content from file stream
    if ext == 'pdf':
        current_app.logger.info("Extracting text from PDF file: %s", filename)
        all_text = extract_pdf_text(file.stream)
    elif ext == 'docx':
        current_app.logger.info("Extracting text from DOCX file: %s", filename)
        all_text = extract_docx_text(file.stream)
    else:
        current_app.logger.error("Unsupported file type uploaded: %s", filename)
        raise ValueError("Unsupported file type.")

    # Format prompt and get response
    current_app.logger.debug("Formatting prompt and invoking LLM.")
    final_prompt = prompt.format(resume_text=all_text)
    response = llm.invoke(final_prompt)
    current_app.logger.info("LLM response successfully generated for file: %s", filename)
    return json.loads(response.content)

# Route: Resume Extraction
@ExtractResume.route('/extract', methods=['POST'])
def extract_text():
    try:
        file = request.files.get('file')
        api_key = request.form.get('api_key')
        model = request.form.get('model')

        if not file or not api_key or not model:
            current_app.logger.warning("Missing file, API key, or model in request")
            return jsonify({"error": "file, api_key, and model are required"}), 400

        result = process_resume_llm(api_key, model, file)
        return jsonify({"llm_response": result})

    except Exception as e:
        current_app.logger.error("Error in extract_text: %s", str(e))
        return jsonify({"error": str(e)}), 500

# Route: Health Check
@ExtractResume.route('/status', methods=['GET'])
def status_resume_extraction():
    current_app.logger.info("Resume extraction status checked.")
    return jsonify(message="Resume extraction service is running."), 200
