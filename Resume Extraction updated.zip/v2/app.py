import os
import logging
from flask import Flask, request, jsonify, Blueprint

#from Package_Commons import setup_nltk


app = Flask(__name__)


''' register all routes '''
from route_common_functions import *
app.register_blueprint(Functions, url_prefix='/function')

from route_google_news import *
app.register_blueprint(GoogleNews, url_prefix='/google-news')

from route_x import *
app.register_blueprint(X, url_prefix='/x')

from route_app_store import *
app.register_blueprint(AppleStore, url_prefix='/app-store')

from route_play_store import *
app.register_blueprint(PlayStore, url_prefix='/play-store')

from route_youtube import *
app.register_blueprint(Youtube, url_prefix='/youtube')

from route_facebook import *
app.register_blueprint(Facebook, url_prefix='/facebook')

from route_instagram import *
app.register_blueprint(Instagram, url_prefix='/instagram')

from route_gemini import *
app.register_blueprint(Gemini, url_prefix='/gemini')

from route_reddit import *
app.register_blueprint(Reddit, url_prefix='/reddit')

from route_serp import *
app.register_blueprint(SerpApi, url_prefix='/serp')

# new feature linkedIN
from route_linkedIn import *
app.register_blueprint(LinkedIn, url_prefix='/linkedin')

from route_tiktok import *
app.register_blueprint(TikTok, url_prefix='/tiktok')

"""
from route_google_search import *
app.register_blueprint(GoogleSearch, url_prefix='/google-search')
"""

''' app configues '''
#app.config['allowed_file_extensions'] = {'pdf', 'docx', 'xlsx'}
#app.config['uploads'] = 'static/uploads'
#os.makedirs(app.config['uploads'], exist_ok=True)

''' enabling logging '''
def configure_logger(app):
    # Set log directory and file in the app's configuration
    app.config['log_dir'] = 'logs'
    app.config['log_file_name'] = 'app.log'
    app.config['log_file_path'] = os.path.join(app.config['log_dir'], app.config['log_file_name'])
    os.makedirs(app.config['log_dir'], exist_ok=True)
    # Create custom logger
    logger = logging.getLogger("flask_app_logger")
    logger.setLevel(logging.DEBUG)  # Set log level

    # Define log format
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # Create handlers
    # Write logs to file
    file_handler = logging.FileHandler(app.config['log_file_path'])  
    file_handler.setFormatter(formatter)
    # Output logs to console
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    # Add handlers to logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    # Attach the custom logger to the Flask app
    app.logger.handlers = logger.handlers
    app.logger.setLevel(logger.level)

# Initialize logging
configure_logger(app)


@app.route('/app/status', methods=['GET'])
def status_app():
    app.logger.info("itrends App is running")
    return jsonify(message="itrends App is running"),200


'''
Clears the content of the log file.
'''
@app.route('/clear-logs', methods=['GET'])
def clear_logs():
    try:
        with open(app.config['log_file_path'], 'w') as log_file:
            log_file.write('')
        app.logger.info(f"{app.config['log_file_path']} cleared successfully")
        return jsonify({'message': f"{app.config['log_file_path']} cleared successfully"}), 200
    except Exception as e:
        app.logger.error(f"Error clearing {app.config['log_file_path']}: {str(e)}")
        return jsonify({"error": f"Failed to clear {app.config['log_file_path']}"}), 500


if __name__ == '__main__':
    app.logger.info("Started\Restarted APP @ ")
    #setup_nltk.download_nltk_packages()
    app.run(debug=True,
            host="0.0.0.0")
