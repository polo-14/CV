from flask import Flask, request, jsonify, Blueprint, current_app

import json
from datetime import datetime, timezone

from apify_client import ApifyClient

from functions_common import datetime_analysis
from functions_common import text_analysis




X = Blueprint('X', __name__)

  
#API to check the status of Instagram
@X.route('/status', methods=['GET'])
def status_x():
        current_app.logger.info("X is running")
        return jsonify(message="X is running"),200

def parse_X_datetime(dt_str):
    try:
        # Parse the RFC 1123-style datetime with timezone
        dt = datetime.strptime(dt_str, "%a %b %d %H:%M:%S %z %Y")
        
        # Convert to UTC and format as ISO 8601 with 'Z'
        return dt.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    
    except Exception as e:
        current_app.logger.error("Error in function parse_X_datetime : " + str(e))
        print("Error in function parse_X_datetime : " + str(e))
        return ""
        

def X_scrapper_post_by_hashtag(api_key,mention,maxItems,sort,start_date,end_date):
        try:
                client = ApifyClient(api_key)
                run_input = {
                        "maxItems": maxItems,
                        "searchTerms": mention.split(","),
                        "sort": sort,
                        "start": start_date,
                        "end": end_date}
                
                run = client.actor("nfp1fpt5gUlBwPcor").call(run_input=run_input)
                return run
        except Exception as e:
                current_app.logger.error("Error in function X_scrapper_post_by_hashtag : "+str(e))
                print("Error in function X_scrapper_post_by_hashtag : "+str(e))
                return []



@X.route('/get-post-by-hashtags', methods=['POST'])
def X_get_post_by_hashtag():
        try:
                mention =  request.form['mention']
                api_key = request.form['api_key']
                #filters
                limit = int(request.form['limit']) or 10
                period = request.form.get('period', '1d')
                lang = request.form.get('lang', 'en')
                #country = request.form.get('country', 'za')
                current_app.logger.info("Fetching X Hashtag details for : "+str(mention))

                #config scrapper run
                sort = "Latest" #default
                end_date = datetime.now().strftime("%Y-%m-%d")
                start_date =  datetime_analysis.calculate_end_date(period).strftime("%Y-%m-%d")
                maxItems = limit

                print("Running for X: ",mention," - ",maxItems)
                run = X_scrapper_post_by_hashtag(api_key,mention,maxItems,sort,start_date,end_date)

                #fetching comments
                posts = []
                #setting up client to loop data
                client = ApifyClient(api_key)
                for item in client.dataset(run["defaultDatasetId"]).iterate_items():
                        post = {}
                        #print("item ",item)
                        
                        #basic
                        post["mention"] = mention
                        post["id"] = item["id"]
                        post["type"] = item.get("type","")
                        post["url"] = item.get("url","")
                        post["lang"] = item["lang"]
                        post["timestamp"] = item["createdAt"]
                        post["date"] = parse_X_datetime(item["createdAt"])
                        #post["date"] = datetime_analysis.convert_to_utc_iso(str(item["createdAt"]))
                        
                        #counts
                        post["retweetCount"] = item.get("retweetCount", 0)
                        post["replyCount"] = item.get("replyCount", 0)
                        post["likeCount"] = item.get("likeCount", 0)
                        post["quoteCount"] = item.get("quoteCount", 0)
                        post["viewCount"] = item.get("viewCount", 0)
                        post["bookmarkCount"] = item.get("bookmarkCount", 0)
                        
                        #other fields
                        post["conversationId"] = item["conversationId"]
                        post["isReply"] = item["isReply"]
                        post["isRetweet"] = item["isRetweet"]
                        post["isQuote"] = item["isQuote"]
                        post["media"] = item["media"]
                        #post["possiblySensitive"] = item.get("possiblySensitive", False)
                        post["isPinned"] = item["isPinned"]
                        post["source"] = item["source"]
                        post["twitterUrl"] = item["twitterUrl"]

                        #author
                        author = {}
                        author["id"] = item["author"].get("id", "")
                        author["type"] = item["author"].get("type", "")
                        author["name"] = item["author"].get("name", "")
                        author["userName"] = item["author"].get("userName", "")
                        author["img"] = item["author"].get("profilePicture", "")
                        author["url"] = item["author"].get("url", "")
                        author["twitterUrl"] = item["author"].get("twitterUrl", "")
                        #author["isVerified"] = item["author"].get("isVerified", "")
                        author["isBlueVerified"] = item["author"].get("isBlueVerified", "")
                        author["location"] = item["author"].get("location", "")
                        author["followers"] = item["author"].get("followers", "")
                        author["following"] = item["author"].get("following", "")
                        post["author"] = author

                        #analysis
                        post["text"] = item["fullText"]
                        analysis = json.loads(text_analysis.get_insight(post["text"]))
                        post["sentiment"] = analysis["sentiment"]
                        post["tags"] = analysis["tags"]
                        post["tansalated"] = analysis["tansalated"]
                        posts.append(post)
                return jsonify(posts)
        except Exception as e:
                current_app.logger.error("Error in /instagram/X_get_post_by_hashtag : "+str(e))
                return jsonify({"error" : str(e)}),500
                  
