from flask import Flask, request, jsonify, Blueprint, current_app

import json

from serpapi import GoogleSearch



SerpApi = Blueprint('SerpApi', __name__)

        
#API to check the status of SerpApi
@SerpApi.route('/status', methods=['GET'])
def status_serpapi():
        current_app.logger.info("SerpApi is running")
        return jsonify(message="SerpApi is running"),200



@SerpApi.route('/interest-by-region', methods=['POST'])
def serp_interest_by_region():
        try:
                api_key = request.form['api_key'] 
                q = request.form['mention']
                geo = request.form['country'] or "ZA"
                data_type = request.form['data_type'] or "GEO_MAP_0"
                resolution = request.form['resolution'] or "REGION"
                params = {
                        "api_key": api_key,
                        "engine": "google_trends",
                        "q": q,
                        "geo" : geo,
                        "data_type": data_type,
                        "resolution":resolution
                        }
                search = GoogleSearch(params)
                results = search.get_dict()
                #interest_by_region = results["interest_by_region"]
                
                return jsonify(results)
        except Exception as e:
                current_app.logger.error("Error in /serp/intrest-by-region : "+str(e))
                return jsonify({"error" : str(e)}),500


@SerpApi.route('/related-queries', methods=['POST'])
def serp_related_queries():
        try:
                api_key = request.form['api_key'] 
                q = request.form['mention']
                geo = request.form['country'] or "ZA"
                data_type = request.form['data_type'] or "RELATED_QUERIES"
                params = {
                        "api_key": api_key,
                        "engine": "google_trends",
                        "q": q,
                        "geo" : geo,
                        "data_type": data_type
                        }
                search = GoogleSearch(params)
                results = search.get_dict()
                #related_queries = results["related_queries"]
                
                return jsonify(results)
        except Exception as e:
                current_app.logger.error("Error in /serp/intrest-by-region : "+str(e))
                return jsonify({"error" : str(e)}),500



