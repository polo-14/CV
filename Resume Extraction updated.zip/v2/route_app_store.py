from flask import Flask, request, jsonify, Blueprint, current_app


from itunes_app_scraper.scraper import AppStoreScraper

import json
from datetime import datetime
from apify_client import ApifyClient

from functions_common import datetime_analysis
from functions_common import text_analysis

AppleStore = Blueprint('AppleStore', __name__)

        
#API to check the status of App Store
@AppleStore.route('/status', methods=['GET'])
def status_app_store():
        current_app.logger.info("App Store is running")
        return jsonify(message="App Store is running"),200

"""
API to get app details like name, description, screenshorts etc
"""
@AppleStore.route('/get-app-details', methods=['POST'])
def apple_app_details():
        try:
                app_name = request.form['app_name']
                app_id =  request.form['app_id']
                country = request.form['country'] or "za"
                scraper = AppStoreScraper()
                current_app.logger.info("Fetching Apple Store details for : "+str(app_id))
                
                details = scraper.get_app_details(app_id, country=country, add_ratings=True )
                return jsonify(details)
        except Exception as e:
                current_app.logger.error("Error in /get-app-details : "+str(e))
                return jsonify({"error" : str(e)}),500



def Apify_app_store_scrapper(api_key,appids,maxItems,until):
        try:
                client = ApifyClient(api_key)
                run_input = {
                        "appIds": appids.split(","),
                        "maxItems": maxItems,
                        "until": until,
                        "customMapFunction": "(object) => { return {...object} }"
                        }
                
                run = client.actor("cS9boBgQBnUglDSWX").call(run_input=run_input)
                return run
        except Exception as e:
                current_app.logger.error("Error in function Apify_app_store_scrapper : "+str(e))
                print("Error in function Apify_app_store_scrapper : "+str(e))
                return []

@AppleStore.route('/get-app-reviews', methods=['POST'])
def apple_app_reviews():
        try:
                api_key = request.form['api_key']
                app_id =  request.form['app_id']
                
                #filters
                limit = int(request.form['limit']) or 10
                period = request.form.get('time_filter', '1d')
                lang = request.form.get('lang', 'en')
                country = request.form.get('country', 'za')
                current_app.logger.info("Fetching Apple Store reviews for : "+str(app_id))

                #config scrapper run
                until =  datetime_analysis.calculate_end_date(period).strftime("%Y-%m-%d")
                maxItems = limit
                
                run = Apify_app_store_scrapper(api_key,app_id,maxItems,until)

                #fetching comments
                overall_responses = []
                #setting up client to loop data
                client = ApifyClient(api_key)
                for item in client.dataset(run["defaultDatasetId"]).iterate_items():
                        response = {}

                        #user details
                        response["author"] = {}
                        response["author"]["name"] = item["userName"]
                        response["author"]["url"] = item["userUrl"]

                        #comment details
                        response["app_id"] = item["appId"]
                        response["id"] = item["id"]
                        response["timestamp"] = item["date"]
                        response["date"] = datetime_analysis.convert_to_utc_iso(item["date"])
                        response["version"] = item["version"]
                        response["score"] = item["score"]
                        response["url"] = item["url"]
                        response["country"] = item["country"]

                        #analysis
                        response["title"] = item["title"]
                        response["text"] = item["text"]
                        analysis = json.loads(text_analysis.get_insight(item["text"]))
                        response["sentiment"] = analysis["sentiment"]
                        response["tags"] = analysis["tags"]
                        response["tansalated"] = analysis["tansalated"]

                        #append
                        overall_responses.append(response)

                return jsonify(overall_responses),200
        except Exception as e:
                current_app.logger.error("Error in /app-store/get-app-reviews : "+str(e))
                return jsonify({"error" : str(e)}),500

                


