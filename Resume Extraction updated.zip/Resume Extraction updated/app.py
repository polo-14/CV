from flask import Flask, jsonify
import logging
import os


# Initialize Flask app
app = Flask(__name__)


# Register Resume Extraction Blueprint
from route_resume import *  
app.register_blueprint(ExtractResume, url_prefix='/resume-ai')


# Health Check Endpoint
@app.route('/app/status', methods=['GET'])
def status_app():
    app.logger.info("✅ App is running")
    return jsonify(message="App is running"), 200


# Configure Logging
def configure_logger(app):
    # Log directory and file path
    log_dir = 'logs'
    log_file = 'app.log'
    log_path = os.path.join(log_dir, log_file)

    # Ensure log directory exists
    os.makedirs(log_dir, exist_ok=True)

    # Logger setup
    logger = logging.getLogger("flask_app_logger")
    logger.setLevel(logging.DEBUG)

    # Log formatter
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # File handler
    file_handler = logging.FileHandler(log_path)
    file_handler.setFormatter(formatter)

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    # Add handlers
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    # Attach to Flask app logger
    app.logger.handlers = logger.handlers
    app.logger.setLevel(logger.level)

# Initialize logging
configure_logger(app)




# run the flask app
if __name__ == '__main__':
    app.logger.info("Started/Restarted itrends APP")
    app.run(debug=True, host="0.0.0.0")
