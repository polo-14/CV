from flask import Blueprint, request, jsonify, current_app
from apify_client import ApifyClient
from functions_common import text_analysis
import json

LinkedIn = Blueprint('LinkedIn', __name__)

@LinkedIn.route('/linkedin-search-posts', methods=['POST'])
def get_linkedin_posts():
    try:
        # Get data from request
        api_key = request.form['api_key']
        mentions = request.form.get('mentions', "AI")
        limit = int(request.form.get('limit', 10))
        sort_by = request.form.get('sort_by', "relevance")
        content_type = request.form.get('content_type', "documents")

        # Apify setup
        client = ApifyClient(api_key)
        run_input = {
            "query": mentions,
            "maxResults": limit,
            "sort_by": sort_by,
            "content_type": content_type
        }

        current_app.logger.info(f"Running LinkedIn scraper with input: {run_input}")
        run = client.actor("Sa8LUWgtparEklk5Y").call(run_input=run_input)

        posts = []
        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
            try:
                post = {}
                post["share_url"] = item.get("share_url")
                post["actor"] = item.get("actor")
                post["commentary"] = item.get("commentary")
                post["social_details"] = item.get("social_details")
                post["postedAt"] = item.get("postedAt")
                post["documentComponent"] = item.get("documentComponent")
                post["urn"] = item.get("urn")
                post["reactionsUrn"] = item.get("reactionsUrn")
                post["commentsUrn"] = item.get("commentsUrn")
                post["repostsUrn"] = item.get("repostsUrn")
                post["scrapedAt"] = item.get("scrapedAt")

                # Sentiment, Tags, Translation
                text = post["commentary"] or ""
                if text:
                    try:
                        analysis = json.loads(text_analysis.get_insight(text))
                        post["sentiment"] = analysis.get("sentiment", "")
                        post["tags"] = analysis.get("tags", [])
                        post["translated"] = analysis.get("tansalated", text)
                    except Exception as e:
                        current_app.logger.error("Sentiment analysis error: " + str(e))
                        post["sentiment"] = ""
                        post["tags"] = []
                        post["translated"] = text
                else:
                    post["sentiment"] = ""
                    post["tags"] = []
                    post["translated"] = ""

                posts.append(post)

            except Exception as e:
                current_app.logger.error("Error while processing LinkedIn post: " + str(e))

        return jsonify(posts)

    except Exception as e:
        current_app.logger.error("LinkedIn scrape error: " + str(e))
        return jsonify({"error": str(e)}), 500


# API to check the status of LinkedIn
@LinkedIn.route('/status', methods=['GET'])
def status_linkedin():
    current_app.logger.info("LinkedIn is running")
    return jsonify(message="LinkedIn is running"), 200