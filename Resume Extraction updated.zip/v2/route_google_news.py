from flask import Flask, request, jsonify, Blueprint, current_app
from gnews import GNews
import json

from functions_common import datetime_analysis
from functions_common import text_analysis

GoogleNews = Blueprint('GoogleNews', __name__)


def get_news(mention,country='us',period='7d',language='en',max_results=200):
        google_news = GNews()
        google_news.period = period
        google_news.country = country
        google_news.language = language
        #google_news.max_results = max_results
        news = google_news.get_news(mention)
        current_app.logger.info(f"Got news for {mention}")
        return news
        
#API to check the status of Google News
@GoogleNews.route('/status', methods=['GET'])
def status_app_google_news():
    current_app.logger.info("Google News App is running")
    return jsonify(message="Google News App is running"),200


''' function to get the google news '''
@GoogleNews.route('/get-news', methods=['POST'])
def get_google_news():
        try:
                mentions = [m.strip() for m in request.form.get('mentions', '').split(',')]
                country = request.form.get('country') or 'za'
                period = request.form.get('time_filter') or '1d'
                language = request.form.get('lang') or 'en'
                limit = int(request.form.get('limit')) or 100
                all_news = []
                for mention in mentions:
                        news = get_news(mention,country,period)
                        for new in news[:limit]:
                                new["mention"]=mention
                                text = new["title"]+" "+new["description"]

                                #analyse news
                                analysis = json.loads(text_analysis.get_insight(text))
                                new["sentiment"] = analysis["sentiment"]
                                new["topic"] = analysis["tags"]
                                new["tansalated"] = analysis["tansalated"]

                                #changing key for UI elements
                                new["timestamp"] = new.pop("published date")
                                new["date"] = datetime_analysis.convert_to_utc_iso(new["timestamp"])
                                all_news.append(new)
                return jsonify(all_news),200
        except Exception as e:
                current_app.logger.error("Error in /news/get-news : "+str(e))
                return []
    

@GoogleNews.route('/supported-languages', methods=['GET'])
def google_news_languages():
    return jsonify(list(GNews().languages)[0]),200
