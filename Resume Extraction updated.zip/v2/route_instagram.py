from flask import Flask, request, jsonify, Blueprint, current_app

from functions_common import datetime_analysis
from functions_common import text_analysis
from function_save_image import save_image_from_url

import json

from collections import defaultdict
from apify_client import ApifyClient

Instagram = Blueprint('Instagram', __name__)


def IG_scrapper_profile_details(userlist,api_key,folder_id="temp_instagram"):
        try:
                client = ApifyClient(api_key)
                # Prepare the Actor input
                run_input = { "usernames": userlist }
                # Run the Actor and wait for it to finish
                run = client.actor("dSCLg0C3YEZ83HzYX").call(run_input=run_input)
                authors ={}
                for item in client.dataset(run["defaultDatasetId"]).iterate_items():
                        author = {}
                        author["mention"] = item["username"]
                        author["id"] = item["username"]
                        print("IG_scrapper_profile_details : ",author["id"])
                        try:
                                if "fullName" in item.keys():
                                        author["name"] = item["fullName"]
                                        author["img_origianl"] = item["profilePicUrl"]
                                        author["img"] = save_image_from_url(item["profilePicUrl"],folder_id)
                                        author["post"] = item["postsCount"]
                                        author["followers"] = item["followersCount"]
                                        author["follows"] = item["followsCount"]
                                        author["private"] = item["private"]
                                        author["biography"] = item["biography"]
                                        author["postsCount"] = item["postsCount"] if "postsCount" in item else 0
                                        author["type"] = "BusinessAccount" if "isBusinessAccount" in item else "User"
                        except Exception as e:
                                current_app.logger.error("Error in getting author details : "+str(item["username"]))
                                print("Error in getting author details : "+str(item["username"]))
                                
                        authors[item["username"]] = author
                return authors
        except Exception as e:
                current_app.logger.error("Error in  function IG_scrapper_profile_details : "+str(e))
                print("Error in function IG_scrapper_profile_details : "+str(e))
                return []
                


def IG_scrapper_post_by_hashtag(api_key,mentions,limit=20):
        try:
                client = ApifyClient(api_key)
                # Prepare the Actor input
                run_input = {
                                "hashtags": mentions.split(","),
                                "resultsType": "posts",
                                "resultsLimit": int(limit)
                            }
                run = client.actor("reGe1ST3OBgYZSsZJ").call(run_input=run_input)
                return run
        except Exception as e:
                current_app.logger.error("Error in function IG_scrapper_post_by_hashtag : "+str(e))
                print("Error in function IG_scrapper_post_by_hashtag : "+str(e))
                return []

def IG_scrapper_comments(api_key,posts,limit=20):
        try:
                client = ApifyClient(api_key)
                # Prepare the Actor input
                run_input = {
                        "directUrls": posts.split(","),
                        "resultsLimit": int(limit)
                        }
                print("run_input : ",run_input)
                run = client.actor("SbK00X0JYCPblD2wp").call(run_input=run_input)
                return run
        except Exception as e:
                current_app.logger.error("Error in function IG_scrapper_comments : "+str(e))
                print("Error in function IG_scrapper_comments : "+str(e))
                return []


#API to check the status of Instagram
@Instagram.route('/status', methods=['GET'])
def status_instagram():
        current_app.logger.info("Instagram is running")
        return jsonify(message="Instagram is running"),200


@Instagram.route('/get-post-by-hashtags', methods=['POST'])
def IG_get_post_by_hashtag():
        try:
                api_key = request.form['api_key']
                # folder_id =  "instagram_"+(request.form['folder_id'] or "instagram_temp")
                folder_id =  "instagram_" + request.form.get('folder_id', 'instagram_temp')
                mentions =  request.form['mentions']
                # limit = int(request.form['limit']) or 20
                limit = int(request.form.get('limit', 20))
                period = request.form.get('time_filter', '1d')
                current_app.logger.info("Fetching Instagram Hashtag details for : "+str(mentions))

                #setting until date
                until =  datetime_analysis.calculate_end_date(period)

                #config scrapper run
                client = ApifyClient(api_key)
                run = IG_scrapper_post_by_hashtag(api_key,mentions,limit)

                #fetching post details
                posts = []
                userlist = []
                for item in client.dataset(run["defaultDatasetId"]).iterate_items():
                        #checking if date time is less than until
                        post_date = datetime_analysis.utc_to_dt(datetime_analysis.convert_to_utc_iso(item["timestamp"]))
                        print("post_date : ",post_date,type(post_date))
                        print("until : ",until,type(until))
                        if until > post_date:
                                continue
                        
                        print("IG fetching post : ",item["url"])
                        post = {}
                        #handling the keys
                        post["hashtags"] = item["hashtags"] if "hashtags" in item else mentions
                        post["mention"] = item["inputUrl"] if "inputUrl" in item else mentions
                        post["likesCount"] = item["likesCount"] if "likesCount" in item else 0
                        post["commentsCount"] = item["commentsCount"] if "commentsCount" in item else 0
                        post["videoUrl"] = item["videoUrl"] if "videoUrl" in item else None
                        #users mentioned in the post
                        post["user_tagged"]    = item["mentions"] if "mentions" in item else []
                        post["id"] = item["id"]
                        post["type"] = item["type"]
                        post["timestamp"] = item["timestamp"]
                        post["date"] = datetime_analysis.convert_to_utc_iso(item["timestamp"])
                        post["text"] = item["caption"]
                        post["url"] = item["url"]
                        post["productType"] = item["productType"]
                        post["isSponsored"] = item["isSponsored"]
                        post["images"] = item["images"]
                        post["user_id"] = item["ownerUsername"]
                        #save post image in local
                        post["displayUrl"] = save_image_from_url(item["displayUrl"],folder_id)
                        posts.append(post)
                        #getting user details
                        if item["ownerUsername"] not in userlist:
                                userlist.append(item["ownerUsername"])
                print("Fetched post of ",len(posts))
                if posts:
                        authors = IG_scrapper_profile_details(userlist,api_key,folder_id)
                        #update author details
                        for post in posts:
                                analysis = json.loads(text_analysis.get_insight(post["text"]))
                                post["sentiment"] = analysis["sentiment"]
                                post["tags"] = analysis["tags"]
                                post["tansalated"] = analysis["tansalated"]
                                post["author"] = authors[post["user_id"]]
                                post.pop("user_id", None)
                print("updated user details")
                return jsonify(posts)
        except Exception as e:
                current_app.logger.error("Error in /instagram/get-post-by-hashtags : "+str(e))
                return jsonify({"error" : str(e)}),500


"""
Get comments for the post
"""
@Instagram.route('/get-comments', methods=['POST'])
def IG_get_comments():
                api_key = request.form['api_key']
                folder_id =  "instagram_"+(request.form['folder_id'] or "instagram_temp")
                posts =  request.form['posts']
                limit = int(request.form['limit']) or 20
                
                print("api_key ",api_key)
                print("posts ",posts)
                print("limit ",limit)
                
                run = IG_scrapper_comments(api_key,posts,limit=20)

                print("Run started")
                #fetching comments
                comments = []
                userlist = []
                client = ApifyClient(api_key)
                for item in client.dataset(run["defaultDatasetId"]).iterate_items():
                        comment = {}
                        if "postUrl" not in item:
                                print("Error in IG fetching comments : ",item["url"])
                                comment["mention"] = item["url"] if "url" in item else "No mention details found"
                                comment["error"] = item["errorDescription"]
                                comment["text"] = ""
                                comment["logs"] = item
                                comments.append(comment)
                                continue
                        print("IG fetching comments : ",item["postUrl"])
                        comment["mention"]= item["postUrl"]
                        comment["id"]= item["id"]
                        comment["name"]= item["owner"]["full_name"]
                        comment["username"]= item["ownerUsername"]
                        comment["img"]= save_image_from_url(item["ownerProfilePicUrl"],folder_id)
                        comment["date"]= datetime_analysis.convert_to_utc_iso(item["timestamp"])
                        comment["replies"]= item["replies"]
                        comment["likesCount"]= item["likesCount"] if "likesCount" in item else 0
                        comment["repliesCount"]= item["repliesCount"] if "repliesCount" in item else 0

                        #getting sentiment for the comments
                        comment["text"] = item["text"]
                        analysis = json.loads(text_analysis.get_insight(item["text"]))
                        comment["sentiment"] = analysis["sentiment"]
                        comment["tags"] = analysis["tags"]
                        comment["tansalated"] = analysis["tansalated"]

                        """
                        #getting user details
                        if item["ownerUsername"] not in userlist:
                                userlist.append(item["ownerUsername"])
                        """
                        comments.append(comment)
                return jsonify(comments)
                """
                #updating user details
                print("Fetched post of ",len(posts))
                if comments:
                        authors = IG_scrapper_profile_details(userlist,api_key,folder_id)
                        #update author details
                        for comment in comments:
                                if "user_id" in comments:
                                        comment["author"] = authors[comment["user_id"]]
                                        comment.pop("user_id", None)
                        # Populate the grouped data
                        # Grouping by mention
                        grouped_comments = defaultdict(list)
                        for entry in comments:
                                mention = entry['mention']
                                grouped_comments[mention].append({k: v for k, v in entry.items() if k != "mention"})
                print("updated user details")
                
                return jsonify(grouped_comments)
                """


"""
Scrap instragram user details
"""
@Instagram.route('/get-user-details', methods=['POST'])
def IG_get_user_details():
        try:
                api_key = request.form['api_key']
                userlist =  request.form['user_ids'].split(",")
                authors = IG_scrapper_profile_details(userlist,api_key)
                return authors
        except Exception as e:
                current_app.logger.error("Error in /instagram/get-user-details : "+str(e))
                return jsonify({"error" : str(e)}),500

