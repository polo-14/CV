import re
import json
import isodate

from flask import Flask, request, jsonify, Blueprint, current_app

from functions_common import datetime_analysis
from functions_common import text_analysis

from googleapiclient.discovery import build

Youtube = Blueprint('Youtube', __name__)


"""
Extract the video ID from a YouTube URL.
"""
def get_video_id(url: str) -> str:
    video_id = re.search(r"(?:v=|\/)([0-9A-Za-z_-]{11}).*", url)
    return video_id.group(1) if video_id else None


"""
Convert ISO 8601 duration string to a human-readable format.
    
Example:
"PT23M14S" -> "23 mins 14 sec"
"PT1H2M3S" -> "1 hr 2 mins 3 sec"
"PT45S" -> "45 sec"
"PT2H" -> "2 hrs"
"""
def convert_duration(iso_duration: str) -> str:
    try:
        # Parse the ISO 8601 duration
        duration = isodate.parse_duration(iso_duration)
        
        total_seconds = int(duration.total_seconds())
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        parts = []
        if hours > 0:
            parts.append(f"{hours} hr{'s' if hours > 1 else ''}")
        if minutes > 0:
            parts.append(f"{minutes} min{'s' if minutes > 1 else ''}")
        if seconds > 0:
            parts.append(f"{seconds} sec")
        
        return ' '.join(parts)
    
    except Exception as e:
        return str(e)

"""
Fetch channel details using channel ID.
Returns a dictionary containing channel info or None if not found.
"""
def get_channel_details(youtube, author_channel_id):
    try:
        channel_response = youtube.channels().list(
            part='snippet,statistics',
            id=author_channel_id
        ).execute()

        if channel_response.get('items'):
            channel_info = channel_response['items'][0]
            return {
                "id": author_channel_id,
                "url": f"https://www.youtube.com/channel/{author_channel_id}",
                "followers": channel_info['statistics'].get('subscriberCount', '0'),
                "totalVideos": channel_info['statistics'].get('videoCount', '0')
            }
        return None

    except Exception as e:
        return {"error": str(e)}


"""
function to fetch the reply for a comment
"""
def fetch_replies_recursive(youtube, parent_id, next_page_token=None):
    all_replies = []
    try:
        # Fetch the replies for the given parent_id (comment_id)
        response = youtube.comments().list(
            part='snippet',
            parentId=parent_id,
            maxResults=100,
            pageToken=next_page_token
        ).execute()
        
        for item in response.get('items', []):
            snippet = item['snippet']
            author_channel_id = snippet.get('authorChannelId', {}).get('value', None)
            text = snippet.get('textDisplay')
            analysis = json.loads(text_analysis.get_insight(text))
            reply = {
                "commentId": item['id'],
                "author": {
                            "id": author_channel_id,
                            "type": "Channel" if author_channel_id else "User",
                            "name": snippet.get('authorDisplayName','Unknown'),
                            "img" : snippet.get('authorProfileImageUrl', ''),
                            "channel_details": get_channel_details(youtube, author_channel_id) if author_channel_id else None
                          },
                "text": text,
                "sentiment" : analysis["sentiment"],
                "tags" : analysis["tags"],
                "tansalated" : analysis["tansalated"],
                "likeCount": snippet.get('likeCount', 0),
                "publishedAt": snippet.get('publishedAt'),
                "updatedAt": snippet.get('updatedAt'),
                "replies": None  # Placeholder for nested replies
            }
            
            # Fetch nested replies for this reply
            nested_replies = fetch_replies_recursive(youtube, reply['commentId'])
            if nested_replies:
                reply['replies'] = nested_replies
            
            all_replies.append(reply)
        
        # Handle pagination if there are more replies to fetch
        if 'nextPageToken' in response:
            all_replies.extend(fetch_replies_recursive(youtube, parent_id, response['nextPageToken']))
        
        return all_replies

    except Exception as e:
        print(f"Error fetching replies: {e}")
        return []

#API to check the status of youtube
@Youtube.route('/status', methods=['GET'])
def status_youtube():
        current_app.logger.info("Youtube is running")
        return jsonify(message="Youtube is running"),200


@Youtube.route('/get-video-details', methods=['POST'])
def get_youtube_video_details():
    api_key = request.form.get('api_key')
    url = request.form.get('url')
    video_id = get_video_id(url)
    if not video_id:
        return jsonify({"error": "Invalid YouTube URL"}), 400
    
    youtube = build('youtube', 'v3', developerKey=api_key)
    
    try:
        # Fetch video details
        video_response = youtube.videos().list(
            part='snippet,contentDetails,statistics,status',
            id=video_id
        ).execute()
        
        if not video_response.get('items'):
            return jsonify({"error": "Video not found"}), 404

        video_data = video_response['items'][0]
        snippet = video_data.get('snippet', {})
        content_details = video_data.get('contentDetails', {})
        statistics = video_data.get('statistics', {})
        status = video_data.get('status', {})

        # Fetch channel details
        channel_id = snippet.get('channelId')
        channel_response = youtube.channels().list(
            part='snippet,statistics',
            id=channel_id
        ).execute()
        channel_data = channel_response['items'][0]

        # Constructing the response
        details = {
            'title': snippet.get('title'),
            'description': snippet.get('description'),
            'publishedAt': snippet.get('publishedAt'),
            'tags': snippet.get('tags', []),
            'channel': {
                'id': channel_id,
                'name': snippet.get('channelTitle'),
                'url': f'https://www.youtube.com/channel/{channel_id}',
                'followers': channel_data['statistics'].get('subscriberCount'),
                'totalVideos': channel_data['statistics'].get('videoCount'),
            },
            'thumbnails': snippet.get('thumbnails', {}),
            'duration': content_details.get('duration'),
            'playtime':convert_duration(content_details.get('duration')),
            'dimension': content_details.get('dimension'),
            'definition': content_details.get('definition'),
            'captionAvailable': content_details.get('caption'),
            'licensedContent': content_details.get('licensedContent'),
            'projection': content_details.get('projection'),
            'viewCount': statistics.get('viewCount'),
            'likeCount': statistics.get('likeCount'),
            'dislikeCount': statistics.get('dislikeCount'),
            'favoriteCount': statistics.get('favoriteCount'),
            'commentCount': statistics.get('commentCount'),
            'privacyStatus': status.get('privacyStatus'),
            'license': status.get('license'),
            'embeddable': status.get('embeddable'),
            'madeForKids': status.get('madeForKids'),
            'ageRestricted': status.get('selfDeclaredMadeForKids') or False  # This is a rough indicator
        }
        return jsonify(details), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@Youtube.route('/get-video-comments', methods=['POST'])
def get_comments():
    api_key = request.form.get('api_key')
    url = request.form.get('url')
    limit = int(request.form.get('limit', 50))
    period = request.form.get('time_filter', '1d')

    #setting until date
    until =  datetime_analysis.calculate_end_date(period)
    
    video_id = get_video_id(url)
    if not video_id:
        return jsonify({"error": "Invalid YouTube URL"}), 400

    youtube = build('youtube', 'v3', developerKey=api_key)

    comments = []
    total_fetched = 0
    next_page_token = None

    try:
        while total_fetched < limit:
            response = youtube.commentThreads().list(
                part='snippet',
                order='time',
                textFormat="plainText",
                videoId=video_id,
                maxResults=min(100, limit - total_fetched),
                pageToken=next_page_token
            ).execute()

            for item in response.get('items', []):
                snippet = item['snippet']['topLevelComment']['snippet']
                
                #checking if date time is less than until
                comment_date = datetime_analysis.utc_to_dt(snippet.get('publishedAt'))
                if until > comment_date:
                    continue
                
                author_channel_id = snippet.get('authorChannelId', {}).get('value')
                text = item['snippet']['topLevelComment']['snippet']['textDisplay']
                analysis = json.loads(text_analysis.get_insight(text))
                comment_data = {
                    "url" : url,
                    "id": item['snippet']['topLevelComment']['id'],
                    "date": snippet.get('publishedAt'), #in UTC format only
                    "text": text,
                    "likes": snippet.get('likeCount', 0),
                    "replies_count": item['snippet'].get('totalReplyCount', 0),
                    "sentiment" : analysis["sentiment"],
                    "tags" : analysis["tags"],
                    "tansalated" : analysis["tansalated"],
                    "author": {
                                "id"  : author_channel_id or None,
                                "type": "Channel" if author_channel_id else "User",
                                "name": snippet.get('authorDisplayName', 'Unknown'),
                                "img" : snippet.get('authorProfileImageUrl', ''),
                                "channel_details": get_channel_details(youtube, author_channel_id) if author_channel_id else None
                                }
                }

                comments.append(comment_data)
                total_fetched += 1

                if total_fetched >= limit:
                    break

            next_page_token = response.get('nextPageToken')
            if not next_page_token:
                break

        #return jsonify({"data": comments})
        return jsonify(comments)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@Youtube.route('/get-comment-replies', methods=['POST'])
def get_youtube_comments_replies():
    api_key = request.form.get('api_key')
    comment_id = request.form.get('comment_id')
    
    if not api_key or not comment_id:
        return jsonify({"error": "api_key and comment_id are required"}), 400

    try:
        youtube = build('youtube', 'v3', developerKey=api_key)
        replies = fetch_replies_recursive(youtube, comment_id)

        return jsonify({"replies": replies}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

