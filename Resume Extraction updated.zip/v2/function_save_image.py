import os
import uuid
import requests
from flask import url_for, current_app

"""
This function is used to save the images from facebook and meta
input : image_url, folder_id
output: url_for of saved image from static folder

"""
def save_image_from_url(image_url, folder_id):
    try:
        # Get extension (safe fallback to .jpg)
        extension = os.path.splitext(image_url)[1].split('?')[0] or '.jpg'
        if not extension.lower() in ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp']:
            extension = '.jpg'

        # Generate unique filename
        unique_filename = f"{uuid.uuid4()}{extension}"

        # Path to save image
        folder_path = os.path.join(current_app.static_folder, folder_id)
        os.makedirs(folder_path, exist_ok=True)
        save_path = os.path.join(folder_path, unique_filename)

        # Add User-Agent header
        headers = {
            'User-Agent': 'MyFlaskApp/1.0 (https://yourdomain.com)'
        }

        # Download with headers
        response = requests.get(image_url, headers=headers, stream=True)
        response.raise_for_status()

        with open(save_path, 'wb') as out_file:
            for chunk in response.iter_content(1024):
                out_file.write(chunk)

        # Return accessible URL
        return url_for('static', filename=f"{folder_id}/{unique_filename}")
        #return url_for('static', filename=f"{folder_id}/{unique_filename}", _external=True)

    except Exception as e:
        current_app.logger.error(f"Error saving image: {e}")
        return None
