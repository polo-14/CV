from flask import Flask, request, jsonify, Blueprint, current_app

import json
import google_play_scraper

from functions_common import datetime_analysis
from functions_common import text_analysis

PlayStore = Blueprint('PlayStore', __name__)

        
#API to check the status of Play Store
@PlayStore.route('/status', methods=['GET'])
def status_app_google_news():
        current_app.logger.info("Play Store App is running")
        return jsonify(message="Play Store App is running"),200


@PlayStore.route('/get-app-details', methods=['POST'])
def get_play_store_app_details():
        try:
                #form values
                app_id = request.form['app_id']
                lang = request.form['lang'] or 'en'
                country = request.form['country'] or 'za'
                current_app.logger.info("Fetching Play Store details for : "+app_id)
                #getting basic app details
                details = google_play_scraper.app(app_id,lang,country)
                #getting permissions details
                details["permissions"] = google_play_scraper.permissions(app_id,lang,country)
                return jsonify(details)
        except Exception as e:
                current_app.logger.error("Error in /get-app-details : "+str(e))
                return jsonify({"error" : str(e)}),500


@PlayStore.route('/get-app-reviews', methods=['POST'])
def get_play_store_app_reviews():
        try:
                #form values
                app_id = request.form['app_id']
                lang = request.form['lang'] or 'en'
                limit = int(request.form['limit']) or 1000
                period = request.form.get('time_filter') or '1d'
                country = request.form['country'] or 'za'

                #setting up time filter for until date
                until_date = datetime_analysis.calculate_end_date(period)
                current_app.logger.info("Fetching Play Store App reviews for : "+str(app_id))
                
                #getting basic app details
                #reviews_by_star = {1: [], 2: [], 3: [], 4: [], 5: []}
                reviews_by_star = [1,2,3,4,5]
                all_reviews = []
                for star in reviews_by_star:
                        try:
                                #Fetch reviews for the given star rating
                                app_reviews, continuation_token = google_play_scraper.reviews(app_id,
                                                                         lang=lang,
                                                                         country=country,
                                                                         sort=google_play_scraper.Sort.NEWEST,
                                                                         count=limit,
                                                                         filter_score_with=star  # Only fetch reviews with this star rating
                                                                         )
                                #adding sentiment & keywords
                                for review in app_reviews:
                                        if review["at"] > until_date:
                                                #chaging date format
                                                review["app_id"] = request.form['app_id']
                                                review["date"] = datetime_analysis.convert_to_utc_iso(str(review["at"]))
                                                review["timestamp"] = review.pop("at")

                                                #analysing content 
                                                analysis = json.loads(text_analysis.get_insight(review["content"]))
                                                review["sentiment"] = analysis["sentiment"]
                                                review["tags"] = analysis["tags"]
                                                review["tansalated"] = analysis["tansalated"]
                                                all_reviews.append(review)
                                current_app.logger.info("Fetching Play Store App reviews for app_star : "+str(app_id)+"_"+str(star))
                        except Exception as e:
                                current_app.logger.error("Error in fetching review for : ",app_id,str(e))
                                # If there's an error, set the review array to empty
                                reviews_by_star[star] = []
                return jsonify(all_reviews)
        except Exception as e:
                current_app.logger.error("Error in /get-app-reviews : "+str(e))
                return jsonify({"error" : str(e)}),500


