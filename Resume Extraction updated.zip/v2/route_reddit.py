from flask import Flask, request, jsonify, Blueprint, current_app
from datetime import datetime, timedelta, timezone

from functions_common import datetime_analysis
from functions_common import text_analysis
#from functions_common.datetime_analysis import *

import praw
import json

Reddit = Blueprint('Reddit', __name__)


#updating the time_filter for reddit format
def config_reddit_time_format(time_filter):
    try:
        #default day
        if not time_filter:
            return "day"

        time_filter = time_filter.lower()
        if time_filter == "all":
            return time_filter
        
        unit = time_filter[-1].lower()
        duration = int(time_filter[:-1])
        if unit == "d":
            if duration == 1:
                return "day"
            else:
                return "week"
        elif unit == "m":
            return "month"
        elif unit == "y":
            return "year"
        else:
            print("Miss match in unit and duration at config_reddit_time_format : ",time_filter)
            return "day"
    except Exception as e:
        print(f"Error Unexpected error at config_reddit_time_format : {e}")
        return None

# Function to initialize Reddit API
def initialize_reddit_api(client_id, client_secret, user_agent):
    try:
        reddit = praw.Reddit(
            client_id=client_id,
            client_secret=client_secret,
            user_agent=user_agent
        )
        # Try to make a simple API call to check authentication
        reddit.user.me()  # This will throw an error if authentication fails
        return reddit
    except RedditAPIException as e:
        print(f"Error Reddit API authentication failed: {e}")
        return None
    except Exception as e:
        print(f"Error Unexpected error during Reddit API initialization: {e}")
        return None


#do not use this function
def handle_rate_limit(reddit):
    while True:
        try:
            reddit.auth.scopes()  # Light API call to check rate limit
            print("Checking rate limit")
            return  # No rate limit issue
        except praw.exceptions.RedditAPIException as e:
            if "RATELIMIT" in str(e):
                wait_time = int("".join(filter(str.isdigit, str(e)))) or 60  # Extract wait time in seconds
                print(f" Rate limit exceeded! Waiting {wait_time} seconds...")
                time.sleep(wait_time)
            else:
                print(f" Unexpected Reddit error: {e}")
                break

#Function to fetch posts for given keywords within a time range
def get_subreddits_with_comments(reddit, keywords, time_filter="1d", lang="en", limit=None):
    results = []
    #start_time = get_time_threshold(time_filter)
    start_time = datetime_analysis.calculate_end_date(time_filter)

    #setting up time_filter for reddit
    print("Reddit input time_filter : ",time_filter)

    time_filter_run = config_reddit_time_format(time_filter)
    print("Reddit updated time_filter run : ",time_filter_run)

    for keyword in keywords:
        print(f"\n Reddit Searching for mention : {keyword}")
        post = 0
        try:
            start_of_today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
            for submission in reddit.subreddit("all").search(keyword, sort="new", time_filter=time_filter_run, limit=limit):
                reddit_time = datetime_analysis.convert_to_utc_iso(int(float(submission.created_utc)))
                print("submission.created_utc : ",submission.created_utc)
                print("start_time : ",start_time,type(start_time))
                print("reddit_time : ",reddit_time,type(reddit_time))
                if start_time and start_time > datetime_analysis.utc_to_dt(reddit_time):
                    print(f"Reddit All posts within {time_filter} collected. Stopping search.")
                    break
                post = post + 1
                print("\n Reddit Fetching Post : ", post, "submission.title : ", submission.title)
                print("URL", f'https://www.reddit.com{submission.permalink}')
                #text analysis
                text = submission.selftext
                title = submission.title
                analysis = json.loads(text_analysis.get_insight(title+" "+text))
                print("\n\n\n submission :",submission)
                #Collect Post Data
                post_data = {
                    "mention" : keyword,
                    "id": submission.id,
                    "title": submission.title,
                    "text": submission.selftext,
                    "is_text":submission.is_self,
                    "url" : f'https://www.reddit.com{submission.permalink}',
                    "display_url" : submission.thumbnail,
                    "link": submission.url,
                    "author": get_user_info(submission.author),
                    "time_stamp": submission.created_utc,
                    "date" : reddit_time,
                    "score": submission.score,
                    "ups": submission.ups,
                    "downs": submission.downs,
                    #"award": get_awards(submission.all_awardings),
                    "num_comments": submission.num_comments,
                    #"comments": get_all_comments(submission),
                    "subreddit": get_subreddit(submission.subreddit),
                    "sentiment":analysis["sentiment"],
                    "tags":analysis["tags"],
                    "tansalated":analysis["tansalated"]
                    
                }
                results.append(post_data)
        except Exception as e:
            print(f"Error fetching posts for {keyword}: {e}")
            current_app.logger.error("Error in function get_subreddits_with_comments : "+str(e))

    return results


# Function to get subreddit infomation
def get_subreddit(subreddit):
    print(f"\nFetching Subreddit :",subreddit)
    if not subreddit:
        return None
    try:
        return {
            "id": subreddit.id,
            "icon_img": subreddit.icon_img,
            "display_name": subreddit.display_name,
            "title": subreddit.title,
            "subscribers": subreddit.subscribers,
            "url": subreddit.url
            }
    except Exception as e:
        print(f"Error fetching subreddit info: {e}")
        current_app.logger.error("Error in function get_subreddit : "+str(e))
        return None

# Function to get award information
def get_awards(award):
    print("Fetching Award")
    if not award:
        return None
    try:
        return {
            "name": award.name,
            "type": award.type
            }
    except Exception as e:
        print(f"Error fetching awards info: {e}")
        current_app.logger.error("Error in function get_awards : "+str(e))
        return None

# Function to fetch user details
def get_user_info(user):
    if not user:
        return None
    try:
        return {
            "name": user.name,
            "id": user.id,
            "img": user.icon_img,
            "url": f"https://www.reddit.com/user/{user.name}",
            "karma": user.link_karma + user.comment_karma,
            "is_top_commenter": "Top 1%" if user.comment_karma > 10000 else "No",
            "is_gold":user.is_gold,
            "cake_cut_age": int((datetime.utcnow() - datetime.utcfromtimestamp(user.created_utc)).days/365),
            "cake_cut_utc": user.created_utc,  # Cake Day (Reddit doesn't provide actual DOB)
            "cake_cut_date": datetime_analysis.convert_to_date(user.created_utc),
            "date" : datetime_analysis.convert_to_utc_iso(int(float(user.created_utc)))
        }
    except Exception as e:
        print(f" Error fetching user info: {e}")
        current_app.logger.error("Error in function get_user_info : "+str(e))
        return None

# Function to fetch all comments & subcomments
# NOTE : for sentiment analysis language is set to "en"
def get_all_comments(submission):
    try:
        print(f"\n Fetching comments")
        submission.comments.replace_more(limit=None)  # Load all comments
        comments_list = []
        for comment in submission.comments.list():
            analysis = json.loads(text_analysis.get_insight(comment.body))
            comments_list.append({
                "id": comment.id,
                "stickied": comment.stickied,
                "score": comment.score,
                "ups": comment.ups,
                "downs": comment.downs,
                "award": get_awards(comment.all_awardings),
                "text": comment.body,
                "author": get_user_info(comment.author),
                "time_stamp": comment.created_utc,
                "date" : datetime_analysis.convert_to_utc_iso(comment.created_utc),
                "replies": get_subcomments(comment.replies) if comment.replies else [],
                "sentiment":analysis["sentiment"],
                "tags":analysis["tags"],
                "tansalated":analysis["tansalated"]
            })
        return comments_list
    except Exception as e:
        print(f" Error fetching user info: {e}")
        current_app.logger.error("Error in function get_all_comments : "+str(e))
        return None



def get_subcomments(comment_replies):
    print(f"\n Fetching replies")
    subcomments = []
    
    # Convert CommentForest to a list of Comment objects
    for reply in list(comment_replies):  # Use list() to convert CommentForest to a list of comments
        analysis = json.loads(text_analysis.get_insight(reply.body))
        subcomment = {
            "id": reply.id,
            "stickied": reply.stickied,
            "score": reply.score,
            "ups": reply.ups,
            "downs": reply.downs,
            "award": get_awards(reply.all_awardings),
            "text": reply.body,
            "author": get_user_info(reply.author),
            "time_stamp": reply.created_utc,
            "date" : datetime_analysis.convert_to_utc_iso(int(float(reply.created_utc))),
            "sentiment":analysis["sentiment"],
            "tags":analysis["tags"],
            "tansalated":analysis["tansalated"]
        }
        
        # Check if the reply has any further replies
        if reply.replies:
            subcomment["subcomments"] = get_subcomments(reply.replies)  # Recursive call to get further replies
        else:
            subcomment["subcomments"] = []
        
        # Append the current subcomment to the subcomments list
        subcomments.append(subcomment)
    
    return subcomments


        
#API to check the status of reddit app
@Reddit.route('/status', methods=['GET'])
def status_app_reddit():
    current_app.logger.info("Reddit App is running")
    return jsonify(message="Reddit App is running"),200

#Flask route to handle the API request
@Reddit.route('/get-reddit-post', methods=['POST'])
def fetch_reddit_data():
    # Fetch form data
    client_id = request.form['client_id']
    client_secret = request.form['client_secret']
    user_agent = request.form['user_agent']
    keywords = request.form['mention'].split(',')  # Comma separated keywords
    subreddit = request.form.get('subreddit', 'all')
    time_filter = request.form.get('time_filter', '1d')
    lang = request.form.get('lang', 'en')
    limit = request.form.get('limit', None)

    #setting limit to int
    if limit:
        limit = int(limit)
    else:
        limit = None

    # Initialize Reddit API with error handling
    reddit = initialize_reddit_api(client_id, client_secret, user_agent)
    if reddit is None:
        return jsonify({"error": "Authentication failed. Please check your Reddit credentials."}), 401

    # Fetch the data
    results = get_subreddits_with_comments(reddit, keywords, time_filter, lang, limit)

    # Return results as JSON response
    return jsonify(results)

# New API to get comments for a specific post
@Reddit.route('/get-reddit-comments', methods=['POST'])
def fetch_reddit_comments():
    try:
        # Fetch form data
        client_id = request.form['client_id']
        client_secret = request.form['client_secret']
        user_agent = request.form['user_agent']
        submission_ids = request.form['submission_ids']  # Fetch the submission ID

        # Initialize Reddit API with error handling
        reddit = initialize_reddit_api(client_id, client_secret, user_agent)
        if reddit is None:
            return jsonify({"error": "Authentication failed. Please check your Reddit credentials."}), 401

        submission_ids = submission_ids.split(",")
        comments = []
        for submission_id in submission_ids:
            try:
                comment = {}
                comment["submission_id"] = submission_id
                # Fetch the submission using the submission ID
                submission = reddit.submission(id=submission_id)
                # Get comments for that post
                comment["comments"] = get_all_comments(submission)
            except Exception as e:
                comment["error"] = str(e)
                print(f"Error fetching comments for submission {submission_id}: {e}")
                current_app.logger.error(f"Error in fetch_reddit_comments: {str(e)}")
            comments.append(comment)
        # Return results as JSON response
        return jsonify(comments)

    except Exception as e:
        print(f"Error in /get-reddit-comments fetching comments for submissions : {e}")
        current_app.logger.error(f"Error in /get-reddit-comments fetching comments for submissions : {e}")
        return jsonify({"error": f"Error fetching comments: {str(e)}"}), 500

@Reddit.route('/supported-languages', methods=['GET'])
def reddit_languages():
    return jsonify({}),200
