import re
import json
import isodate

from flask import Flask, request, jsonify, Blueprint, current_app

from functions_common import sentiment_analysis
from functions_common import keyword_extractor

from pytrends.request import TrendReq


import requests
from urllib.parse import quote


GoogleSearch = Blueprint('GoogleSearch', __name__)



#API to check the status of GoogleTrends
@GoogleSearch.route('/status', methods=['GET'])
def status_googletrends():
        current_app.logger.info("Google Search is running")
        return jsonify(message="Google Search is running"),200


@GoogleSearch.route('/mention-suggestions', methods=['POST'])
def google_keyword_suggestion():
        try:
            # Get form data
            mention = request.form.get('mention')
            country = request.form.get('country')
            lang = request.form.get('lang')
            client=request.form.get('client','chrome') or 'chrome'
            domain=request.form.get('domain',None) or None
            base_url = "https://suggestqueries.google.com/complete/search"

            params = {
                    'client': client,
                    'q': quote(mention),
                    'gl': country,
                    'hl': lang,
                    'domain':None
                    }

            headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
            try:
                    current_app.logger.info("Fetching Google Keyword Suggestion for : "+str(mention))
                    response = requests.get(base_url, params=params, headers=headers)
                    response.raise_for_status()
                    suggestions = json.loads(response.text)[1]
                    return jsonify({"suggestions" : suggestions})
            except Exception as e:
                    current_app.logger.error("Error in GoogleTrends /mention-suggestions : "+str(e))
                    return jsonify({"error" : str(e)}),500
        except Exception as e:
                current_app.logger.error("Error in GoogleTrends /mention-suggestions : "+str(e))
                return jsonify({"error" : str(e)}),500






@GoogleSearch.route('/interest-over-time', methods=['POST'])
def interest_over_time():
    try:
        # Get form data
        mentions = request.form.get('mentions')
        country = request.form.get('country')
        lang = request.form.get('lang')
        hl = lang+"-"+country
        tz = int(request.form.get('tz', 120))  # Default to 120 UTC of SA
        current_app.logger.info("Fetching Google Trends for : "+str(mentions))
        
        # Initialize the pytrends object with dynamic hl and tz
        pytrends = TrendReq(hl=hl, tz=tz)
        pytrends.build_payload(mentions.split(","))
        data = pytrends.interest_over_time()

        if data.empty:
            return jsonify({"error": "No data found for the given keyword"}), 404
        data.index = data.index.astype(str)
        return jsonify(data.to_dict())
    except Exception as e:
        current_app.logger.error("Error in GoogleTrends /interest-over-time : "+str(e))
        return jsonify({"error" : str(e)}),500



@GoogleSearch.route('/trends-mentions-suggestions', methods=['POST'])
def trends_mentions_suggestions():
    try:
        mentions = request.form.get('mentions')
        country = request.form.get('country')
        lang = request.form.get('lang')
        hl = lang+"-"+country
        tz = int(request.form.get('tz', 120))  # Default to 120 UTC of SA
        current_app.logger.info("Fetching Google Trends mentions suggestions for : "+str(mentions))

        if not mentions:
            return jsonify({"error": "mentions parameter is required"}), 400

        pytrends = TrendReq(hl=hl, tz=tz)
        data = pytrends.suggestions(keyword=mentions)

        return jsonify(data)
    except Exception as e:
        current_app.logger.error("Error in GoogleTrends /mentions-suggestions : "+str(e))
        return jsonify({"error" : str(e)}),500





#not working
'''
@GoogleTrends.route('/interest-by-region', methods=['POST'])
def interest_by_region():
        mentions = request.form.get('mentions')
        country = request.form.get('country')
        lang = request.form.get('lang')
        hl = lang+"-"+country
        tz = int(request.form.get('tz', 120))  # Default to 120 UTC of SA
        current_app.logger.info("Fetching Google Trends mentions suggestions for : "+str(mentions))

        if not mentions:
            return jsonify({"error": "Keyword parameter is required"}), 400
        pytrends = TrendReq(hl=hl, tz=tz)
        pytrends.build_payload(mentions.split(","))
        data = pytrends.interest_by_region()
        if data.empty:
            return jsonify({"error": "No data found for the given keyword"}), 404
        return jsonify(data.to_dict())


@GoogleTrends.route('/historical-data', methods=['POST'])
def historical_data():
    mentions = request.form.get('mentions')
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')
    hl = request.form.get('hl', 'en-US')
    tz = int(request.form.get('tz', 360))

    if not mentions or not start_date or not end_date:
        return jsonify({"error": "Keyword, start_date, and end_date are required"}), 400

    pytrends = TrendReq(hl=hl, tz=tz)
    pytrends.build_payload(mentions.split(","), cat=0, timeframe=f'{start_date} {end_date}')
    data = pytrends.get_historical_interest([keyword], year_start=int(start_date[:4]), month_start=int(start_date[5:7]), day_start=int(start_date[8:]), year_end=int(end_date[:4]), month_end=int(end_date[5:7]), day_end=int(end_date[8:]))

    if data.empty:
        return jsonify({"error": "No historical data found for the given parameters"}), 404

    return jsonify(data.to_dict())

@GoogleTrends.route('/trending-searches', methods=['POST'])
def trending_searches():
    region = request.form.get('region', 'united_states') 
    hl = request.form.get('hl', 'en-US')
    tz = int(request.form.get('tz', 360))
    
    pytrends = TrendReq(hl=hl, tz=tz)
    data = pytrends.trending_searches(pn=region)

    return jsonify(data.tolist())

@GoogleTrends.route('/top-charts', methods=['POST'])
def top_charts():
    date = request.form.get('date', '2021')  # Default to '2021'
    category = request.form.get('category', 'all')  # Default to 'all'
    hl = request.form.get('hl', 'en-US')
    tz = int(request.form.get('tz', 360))

    pytrends = TrendReq(hl=hl, tz=tz)
    data = pytrends.top_charts(date, hl=hl, tz=tz, category=category)

    return jsonify(data.to_dict())

#not working 
@GoogleTrends.route('/related-queries', methods=['POST'])
def related_queries():
        # Get form data
        mentions = request.form.get('mentions')
        country = request.form.get('country')
        lang = request.form.get('lang')
        hl = lang+"-"+country
        tz = int(request.form.get('tz', 120)) 
        current_app.logger.info("Fetching Google Trends related queries for : "+str(mentions))
        
        # Initialize the pytrends object with dynamic hl and tz
        pytrends = TrendReq(hl=hl, tz=tz)
        pytrends.build_payload(mentions)
        data = pytrends.related_queries()
        print("\n\n data :",data)
        if keyword not in data:
            return jsonify({"error": "No related queries found for the given keyword"}), 404
        return jsonify(data[keyword])
'''
