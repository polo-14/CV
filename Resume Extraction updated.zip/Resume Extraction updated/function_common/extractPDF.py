from langchain_community.document_loaders import PyMuPDFLoader
from tempfile import NamedTemporaryFile
import os

def extract_pdf_text(file_stream):
    with NamedTemporaryFile(delete=False, suffix=".pdf") as temp_file:
        temp_file.write(file_stream.read())
        temp_file_path = temp_file.name
    try: 
        loader = PyMuPDFLoader(temp_file_path)
        pages = loader.load()
        return " ".join([page.page_content for page in pages])
    finally:
        os.remove(temp_file_path) 