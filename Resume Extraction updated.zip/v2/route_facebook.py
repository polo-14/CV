from flask import Flask, request, jsonify, Blueprint, current_app

import json

from functions_common import datetime_analysis
from functions_common import text_analysis
from function_save_image import save_image_from_url


from datetime import datetime
from apify_client import ApifyClient

Facebook = Blueprint('Facebook', __name__)

        
#API to check the status of Facebook
@Facebook.route('/status', methods=['GET'])
def status_instagram():
        current_app.logger.info("Facebook is running")
        return jsonify(message="Facebook is running"),200

"""

Function to get the posts from facebook search by #tag

Notes :
country not working, should be a place,
Add in run_input "location": "south africa",
                
"""
@Facebook.route('/get-post-by-hashtags', methods=['POST'])
def FB_get_post_by_hashtag():
        try:
                print("request.form ",request.form)
                api_key = request.form['api_key']
                folder_id =  "facebook_"+(request.form['folder_id'] or "facebook_temp")
                mentions =  request.form['mentions']
                limit = int(request.form['limit']) or 20
                time_filter = request.form.get('time_filter', '1d')
                lang = request.form.get('lang', 'en')
                country = request.form.get('country', '')
                current_app.logger.info("Fetching Facebook Hashtag details for : "+str(mentions))

                #configuring time
                start_date = datetime.now().strftime("%Y-%m-%d")
                end_date   = datetime_analysis.calculate_end_date(time_filter).strftime("%Y-%m-%d")

                #executing the scrapper
                fb_posts = []
                client = ApifyClient(api_key)
                for mention in mentions.split(","):                 
                        run_input = {
                                        "query": mention,
                                        "search_type": "posts",
                                        "max_posts": limit,
                                        "start_date": start_date,
                                        "end_date": end_date,
                                        "recent_posts": True
                                    }
                        # Run the Actor and wait for it to finish
                        run = client.actor("l6CUZt8H0214D3I0N").call(run_input=run_input)
                        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
                                post = {}
                                post["mention"] = mention
                                post["id"] = item["post_id"]
                                post["type"] = item["type"]
                                post["url"] = item["url"]
                                post["date"] = datetime_analysis.convert_to_utc_iso(item["timestamp"])
                                post["timestamp"] = item["timestamp"]
                                post["likesCount"] = item["reactions_count"]
                                post["commentsCount"] = item["comments_count"]
                                post["shareCount"] = item["reshare_count"]
                                post["reactions"]    = item["reactions"]

                                #adding author details
                                post["author"] = {}
                                post["author"]["id"] = item["author"]["id"]
                                post["author"]["name"] = item["author"]["name"]
                                post["author"]["url"] = item["author"]["url"]
                                post["author"]["img_origianl"] = item["author"]["profile_picture_url"]
                                post["author"]["img"] = save_image_from_url(item["author"]["profile_picture_url"], folder_id)
                                
                                #post text
                                post["text"] = item["message"]
                                analysis = json.loads(text_analysis.get_insight(item["message"]))
                                post["sentiment"] = analysis["sentiment"]
                                post["tags"] = analysis["tags"]
                                post["tansalated"] = analysis["tansalated"]

                                #append the results
                                fb_posts.append(post)
                return jsonify(fb_posts)
        except Exception as e:
                current_app.logger.error("Error in /facebook/get-post-by-hashtags : "+str(e))
                return jsonify({"error" : str(e)}),500


"""
Get comments for the post
"""
@Facebook.route('/get-comments', methods=['POST'])
def FB_get_comments():
        try:
                api_key = request.form['api_key']
                posts =  request.form['posts']
                limit = int(request.form['limit']) or 20
                folder_id =  "facebook_"+(request.form['folder_id'] or "facebook_temp")
                current_app.logger.info("Fetching Facebook Comments details for : "+str(posts))

                comments = []
                client = ApifyClient(api_key)
                for post in posts.split(","):
                        print("Post : ",post)
                        post_id = post.split("/")[-1]
                        comment = {}
                        comment["mention"] = post
                        comment["post_id"] = post_id
                        comment["comment"] = []
                        if "pfbid" not in post_id:
                                comment["error"]   = "Not a valid post id"
                                comments.append(comment)
                                continue

                        #executing appify runner 
                        run_input = {
                                "post_id": post_id,
                                "max_comments": limit
                                }
                        run = client.actor("dZoIFO1qTxGTq99uR").call(run_input=run_input)
                        
                        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
                                comm = {}
                                
                                #adding author details
                                comm["author"] = {}
                                comm["author"]["id"] = item["author"]["id"]
                                comm["author"]["name"] = item["author"]["name"]
                                comm["author"]["url"] = item["author"]["url"]
                                if "profile_picture_url" in item["author"].keys():
                                        comm["author"]["img"] = save_image_from_url(item["author"]["profile_picture_url"], folder_id)
                                else:
                                        comm["author"]["img"] = ""

                                #adding comment details
                                comm["id"]   = item["comment_id"]
                                comm["type"] = item["type"]
                                comm["comment_id"] = item["comment_id"]
                                comm["legacy_comment_id"] = item["legacy_comment_id"]
                                comm["depth"] = item["depth"]
                                comm["timestamp"] = item["created_time"]
                                comm["date"] = datetime_analysis.convert_to_utc_iso(item["created_time"])
                                comm["replyCount"] = item["replies_count"]
                                comm["likesCount"] = item["reactions_count"]
                                comm["expansion_token"] = item["expansion_token"]

                                #comment text
                                comm["text"]    = item["message"]
                                analysis = json.loads(text_analysis.get_insight(item["message"]))
                                comm["sentiment"]= analysis["sentiment"]
                                comm["topic"]   = analysis["tags"]
                                comm["tansalated"]   = analysis["tansalated"]
                                comment["comment"].append(comm)
                        comments.append(comment)  
                return jsonify(comments)
        except Exception as e:
                current_app.logger.error("Error in /facebook/get-comments : "+str(e))
                return jsonify({"error" : str(e)}),500

                        
