from flask import Flask, request, jsonify, Blueprint, current_app
import json
Functions = Blueprint('Functions', __name__)

from functions_common import text_analysis
from function_save_image import save_image_from_url


Functions = Blueprint('Functions', __name__)

#API to check the status of Common Functions APP
@Functions.route('/status', methods=['GET'])
def status_app_sentiment():
    current_app.logger.info("Common Functions App is running")
    return jsonify(message="Common Functions App is running"),200


"""
route to analyse the input text
return : Sentiment, Compound, Translated text, JSON format 
"""
@Functions.route('/analyse-text', methods=['POST'])
def route_analyse_text():
    try:
        text = request.form.get('text', '')
        if not text:
            return jsonify(message="text is required to analyse"),400
        return jsonify(json.loads(text_analysis.get_insight(text))),200
    except Exception as e:
        current_app.logger.error("Error in /analyse-text : "+str(e))
        return []

"""
route to save the image at static folder
returns : image path
"""
@Functions.route('/upload-image', methods=['POST'])
def upload_image():
    try:
        image_url = request.json.get('image_url')
        folder_id = request.json.get('folder_id')

        if not image_url or not folder_id:
            return jsonify({'error': 'Missing image_url or folder_id'}), 400

        saved_url = save_image_from_url(image_url, folder_id)
        if saved_url:
            return jsonify({'image_url': saved_url}), 200
        else:
            return jsonify({'error': 'Failed to save image'}), 500
    except Exception as e:
        current_app.logger.error("Error in /upload-image : "+str(e))
        return []
