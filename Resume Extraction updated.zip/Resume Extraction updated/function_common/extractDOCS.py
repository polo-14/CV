import docx2txt
from tempfile import NamedTemporaryFile
import os

def extract_docx_text(file_stream):
    """Extract text from DOCX file stream using temporary file method."""
    with NamedTemporaryFile(delete=False, suffix=".docx") as temp_file:
        temp_file.write(file_stream.read())
        temp_file_path = temp_file.name

    try:
        return docx2txt.process(temp_file_path)
    finally:
        os.remove(temp_file_path)  