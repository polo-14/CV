from flask import Flask, request, jsonify, Blueprint, current_app

import json
import google.generativeai as genai

Gemini = Blueprint('Gemini', __name__)


def clean_json(response):
        try:
                if "```json" in response:
                        response = response.replace("```json","").replace("```","")
                        response = json.loads(response)
                return response
        except Exception as e:
                current_app.logger.error("Error in clean_json : "+str(e))
                return response

#API to check the status of Gemini
@Gemini.route('/status', methods=['GET'])
def status_instagram():
        current_app.logger.info("Gemini AI is running")
        return jsonify(message="Gemini AI is running"),200


@Gemini.route('/generate', methods=['POST'])
def genai_generate():
        try:
                api_key = request.form['api_key'] 
                model = request.form['model']
                prompt = request.form['prompt']
                print("prompt : ",prompt)
                genai.configure(api_key=api_key)
                model = genai.GenerativeModel(model)
                response = model.generate_content(prompt)
                print("response : ",response.text)
                response = clean_json(response.text)
                return jsonify(response)
        except Exception as e:
                current_app.logger.error("Error in /instagram/get-post-by-hashtags : "+str(e))
                return jsonify({"error" : str(e)}),500
