from email.utils import parsedate_to_datetime
import pendulum

"""
    Converts any datetime input (string or timestamp) to UTC ISO 8601 format.

    Args:
        value (str|int|float): The input datetime (any format or timestamp).

    Returns:
        str: ISO 8601 formatted UTC datetime string.
"""
def convert_to_utc_iso(dt):
    try:
        # If value is a Unix timestamp (int or float), convert to pendulum datetime
        if isinstance(dt, (int, float)):
            moment = pendulum.from_timestamp(dt)
        elif isinstance(dt, str):
            # Handle RFC 1123 formatted string like 'Sun, 01 Jun 2025 21:36:57 GMT'
            if ',' in dt and 'GMT' in dt:
                dt_obj = parsedate_to_datetime(dt)
                moment = pendulum.instance(dt_obj)
            else:
                moment = pendulum.parse(dt)
        else:
            return "Unsupported input type."

        # Return the ISO 8601 UTC datetime
        return moment.in_timezone('UTC').to_iso8601_string()

    except Exception as e:
        return f"Error parsing date: {e}"


from datetime import datetime, timedelta, timezone
"""
Function to convert the UTC date to date time format
"""
def convert_to_date(timestamp):
    return datetime.utcfromtimestamp(timestamp).strftime('%d-%m-%Y %H:%M:%S')


def utc_to_dt(timestamp):
    return datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%SZ")



"""
Function to get the time threshold
"""
def get_time_threshold(time_filter):
    now = datetime.now(timezone.utc)

    time_mapping = {
        "hour": now - timedelta(hours=1),
        "day": now - timedelta(days=1),
        "week": now - timedelta(weeks=1),
        "month": now - timedelta(days=30),  # Approximate month
        "year": now - timedelta(days=365),  # Approximate year
        "all": None  # No filtering needed
    }

    return time_mapping.get(time_filter, None).timestamp() if time_filter != "all" else None


from datetime import datetime
from dateutil.relativedelta import relativedelta


def calculate_end_date(dt: str):
    if dt == "all" or not dt:
        return None
    # Get the current date
    current_date = datetime.now()

    # Extract the number and time unit from the input string
    duration = int(dt[:-1])  # All except last character (e.g., 6 from "6m")
    unit = dt[-1]  # The last character (e.g., 'm' from "6m")

    if unit == 'h':  # Hours
        end_date = current_date - relativedelta(hours=duration)
    elif unit == 'd':  # Days
        end_date = current_date - relativedelta(days=duration)
    elif unit == 'm':  # Months
        end_date = current_date - relativedelta(months=duration)
    elif unit == 'y':  # Years
        end_date = current_date - relativedelta(years=duration)
    else:
        #default if no match
        print("Invalid time unit. Use 'h', 'd', 'm', or 'y'.")
        end_date = current_date - relativedelta(days=duration)

    return end_date
