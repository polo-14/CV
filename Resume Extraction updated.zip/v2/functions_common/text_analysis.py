import re
import json
import yake

from deep_translator import GoogleTranslator
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

"""
Helps to Analyse the Text Message

Summary of Compound Score Ranges:
-1    to -0.05 : Negative sentiment
-0.05 to +0.05 : Neutral sentiment
+0.05 to +1    : Positive sentiment

"""
def get_insight(text):
    try:
        analysis = {}
        analysis["error"] = []
        analysis["tansalated"] = ""
        
        #setting default values
        analysis["sentiment"] = {}
        analysis["sentiment"]["state"] = "Neutral"
        analysis["sentiment"]["compound"] = 0

        #setting up tag values
        analysis["tags"] = {}
        analysis["tags"]["topic"] = []
        analysis["tags"]["hashtags"] = []
        

        #to handle any smily or emojiee
        if not text:
            analysis["error"] = "Empty Text Response"
            return json.dumps(analysis)

        #translate text
        try:
            text = GoogleTranslator(source="auto", target="en").translate(str(text))
            analysis["tansalated"] = text
        except Exception as e:
            print("unable to translate text : ",text)
            analysis["error"].append(str(e))

        #to handle sentiment
        analysis["sentiment"]["compound"] = SentimentIntensityAnalyzer().polarity_scores(text)['compound']
        if analysis["sentiment"]["compound"] >= 0.05 :
            analysis["sentiment"]["state"]="Positive"
        elif analysis["sentiment"]['compound'] <= -0.05 :
            analysis["sentiment"]["state"]="Negative"

        #to handle keywords
        analysis["tags"]["topic"] = extract_topic(text,top=3,lang="en")
        hashtags = extract_hashtags(text)
        if hashtags:
            analysis["tags"]["hashtags"] = hashtags

        return json.dumps(analysis)
    except Exception as e:
        print("text_analysis Error : ",str(e))
        analysis["error"].append(str(e))
        return json.dumps(analysis)


"""
function to get the topics from the content
"""
def extract_topic(text,top=3,lang="en"):
    try:
        top_keywords = []
        yake_extractor = yake.KeywordExtractor(lan=lang, top=top)
        keywords = yake_extractor.extract_keywords(text)
        top_keywords = [keyword[0] for keyword in keywords]
        return top_keywords
    except Exception as e:
        print("Error occured at function extract_topic :",str(e))
        return []

"""
function that extracts hashtags from a given content
"""
def extract_hashtags(text):
    try:
        return re.findall(r'#\w+', text)
    except Exception as e:
        print("Error occured at function extract_hashtags :",str(e))
        return []
